

import java.sql.Connection;
import java.sql.DriverManager;


public class Dbconnect {
	
	static Connection con=null;
	
	
	public static Connection con()
	{
	try {
		Class.forName(Dbinitializer.Driver);
		con = DriverManager.getConnection(Dbinitializer.db,Dbinitializer.username,Dbinitializer.password);
		return con;
		
		
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		return con;
	}
	}

}
