import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class AccountDEtails {

	
	JTextField TxAccNo;
	
	JTextField Txpin;
	
	JTextField TxAmount;
	
	JTextField TxDept;
	JTextField TxEmail;
	
public AccountDEtails() {
	// TODO Auto-generated constructor stub

	final JFrame f=new JFrame("Account Details");
	f.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
	f.setLayout(null);   
	f.setVisible(true);
	f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
	
	JLabel Head=new JLabel("Account Details");
	Head.setBounds(400, 50, 200, 30);
	Head.setFont(new Font("Rockwell", Font.BOLD, 18));
	Head.setForeground(new Color( 49, 19, 62 ));
	f.add(Head);
	
	JButton b=new JButton("Go To ATM");
	b.setBounds(550, 50, 150, 30);
	b.setFont(new Font("Rockwell", Font.BOLD, 18));
	b.setForeground(new Color( 49, 19, 62 ));
	f.add(b);
	
	b.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			MainMenu s=new MainMenu();
            s.Password();
            f.dispose();
		}
	});
	
	JLabel Acc=new JLabel("Account No:");
	Acc.setBounds(400, 90, 150, 30);
	Acc.setFont(new Font("Rockwell", Font.BOLD, 18));
	Acc.setForeground(new Color( 49, 19, 62 ));
	f.add(Acc);
	
	TxAccNo=new JTextField(25);
	TxAccNo.setBounds(510, 90, 200, 30);
	TxAccNo.setFont(new Font("Rockwell", Font.BOLD, 18));
	TxAccNo.setForeground(new Color( 49, 19, 62 ));
	f.add(TxAccNo);
	
	   
	   JLabel pin=new JLabel("Pin          :");
		pin.setBounds(400, 130, 100, 30);
		pin.setFont(new Font("Rockwell", Font.BOLD, 18));
		pin.setForeground(new Color( 49, 19, 62 ));
	    f.add(pin);
		   
		   Txpin=new JTextField(25);
		   Txpin.setBounds(510, 130, 200, 30);
		   Txpin.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Txpin.setForeground(new Color( 49, 19, 62 ));
		   f.add(Txpin);
		   
	   
	JLabel amount=new JLabel("Amount  :");
	amount.setBounds(400, 170, 100, 30);
	amount.setFont(new Font("Rockwell", Font.BOLD, 18));
	amount.setForeground(new Color( 49, 19, 62 ));
	f.add(amount);
	
	TxAmount=new JTextField(25);
	TxAmount.setBounds(510, 170, 200, 30);
	TxAmount.setFont(new Font("Rockwell", Font.BOLD, 18));
	TxAmount.setForeground(new Color( 49, 19, 62 ));
	   f.add(TxAmount);
	   
	JLabel depts=new JLabel("Depts      :");
	depts.setBounds(400, 210, 100, 30);
	depts.setFont(new Font("Rockwell", Font.BOLD, 18));
	depts.setForeground(new Color( 49, 19, 62 ));
	f.add(depts);
	
	TxDept=new JTextField(25);
	TxDept.setBounds(510, 210, 200, 30);
	TxDept.setFont(new Font("Rockwell", Font.BOLD, 18));
	TxDept.setForeground(new Color( 49, 19, 62 ));
	f.add(TxDept);
	
	JLabel email=new JLabel("Email      :");
	email.setBounds(400, 250, 100, 30);
	email.setFont(new Font("Rockwell", Font.BOLD, 18));
	email.setForeground(new Color( 49, 19, 62 ));
	f.add(email);
	
	TxEmail=new JTextField(25);
	TxEmail.setBounds(510, 250, 200, 30);
	TxEmail.setFont(new Font("Rockwell", Font.BOLD, 18));
	TxEmail.setForeground(new Color( 49, 19, 62 ));
	f.add(TxEmail);
	
	JButton sub=new JButton("Submit");
	sub.setBounds(500, 300, 100, 30);
	sub.setFont(new Font("Rockwell", Font.BOLD, 18));
	sub.setForeground(new Color( 49, 19, 62 ));
	f.add(sub);
	
	sub.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
		
			try{
				String sql1="insert into atm.userdetails values(?,?,?,?,?)";
				PreparedStatement pst=Dbconnect.con().prepareStatement(sql1);
				
				pst.setString(1, TxAccNo.getText());
				pst.setString(2, TxEmail.getText());
				pst.setString(3, TxAmount.getText());
				pst.setString(4, Txpin.getText());
				pst.setString(5, TxDept.getText());
				
				int count=pst.executeUpdate();
				if(count>0)
				{
					
					JOptionPane.showMessageDialog(null, "Record Inserted successfully");
					MainMenu s=new MainMenu();
		            s.Password();
		            f.dispose();
				}
				
			}
			catch(Exception e4)
			{
				JOptionPane.showMessageDialog(null, e4.getMessage());
				e4.printStackTrace();
			}
			
		}
	});
	
	JButton can=new JButton("Cancel");
	can.setBounds(610, 300, 100, 30);
	can.setFont(new Font("Rockwell", Font.BOLD, 18));
	can.setForeground(new Color( 49, 19, 62 ));
    f.add(can);
}
	public static void main(String[] args) {
		new AccountDEtails();

	}

}
