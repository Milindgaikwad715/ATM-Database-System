import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTextField;


public class HomePage {

	public HomePage() {
		// TODO Auto-generated constructor stub
		
		ImagePanel p1 = new ImagePanel(new ImageIcon("ATMDB.jpg").getImage());//Create the obj & call the constructr
	    final JFrame f1=new JFrame("LoginForm");
	    f1.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH); //To keep the Frame in full size view all time
	    
	    JLabel Heading=new JLabel("Welcome To The ATM DATABASE ");
	    Heading.setBounds(300, 20, 550, 30);
	    Heading.setFont(new Font("Rockwell", Font.BOLD, 30));
	    Heading.setForeground(new Color(108, 52, 131));
	    p1.add(Heading);
	    
	    
	    
	    //Start Admin Button
	    ImageIcon icon = new ImageIcon("user.png");
	    
	    JButton Admin=new JButton("USER",icon);
	    Admin.setBounds(100, 180, 320, 250);
	    Admin.setFont(new Font("Rockwell", Font.BOLD, 18));
	    Admin.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Admin);
		   
		   Admin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new UserSide();
				f1.dispose();//close the current frame when switched to next frame
			
				
			}
		});
		   
		   //End Admin Button
		   
		   
		 /*//Start User Button
		   ImageIcon icon1 = new ImageIcon("user.png");
           JButton User=new JButton("USER",icon1);
		   User.setBounds(450, 180, 320, 250);
		   User.setFont(new Font("Rockwell", Font.BOLD, 18));
		   User.setForeground(new Color( 49, 19, 62 ));
		   
		   User.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					new UserSide();
					f1.dispose();//close the current frame when switched to next frame
				
					
				}
			}); 
		   
			   p1.add(User);
			   
		//Start User Button    
	    */
	//f1.setJMenuBar(menubar.menuBar());// just call the Menubar Class & its constructor
	f1.add(p1);
	//f1.setSize(500, 500);
	
	f1.setDefaultCloseOperation(f1.EXIT_ON_CLOSE);
	f1.setVisible(true);
	}
	public static void main(String[] args) {
		
		 new HomePage();
	}

}
