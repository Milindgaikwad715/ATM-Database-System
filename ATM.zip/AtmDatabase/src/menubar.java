import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;

public class menubar {
	
public static JMenuBar menuBar(){
	
	
	   JMenuBar menubar = new JMenuBar();
	   menubar.setBackground(Color.yellow);
	   menubar.setSize(699, 699);
	   
	  
	   JMenu filemenu = new JMenu("File");
	   filemenu.add(new JSeparator());
	   filemenu.setFont(new Font("Rockwell", Font.BOLD, 18));
	   filemenu.setForeground(new Color( 49, 19, 62 ));
	   filemenu.setMnemonic(KeyEvent.VK_F);//Alt+f
	   
	   
	   JMenuItem fileItem1 = new JMenuItem("New");
	   fileItem1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem1.setForeground(new Color( 49, 19, 62 ));
	
	   fileItem1.setAccelerator(KeyStroke.getKeyStroke('N', Toolkit.getDefaultToolkit ().getMenuShortcutKeyMask()));

	   JMenuItem fileItem2 = new JMenuItem("Open");
	   fileItem2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem2.setForeground(new Color( 49, 19, 62 ));
	   fileItem2.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   JMenuItem fileItem3 = new JMenuItem("Close");
	   fileItem3.add(new JSeparator());
	   fileItem3.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem3.setForeground(new Color( 49, 19, 62 ));
	   
	   JMenuItem fileItem4 = new JMenuItem("Save");
	   fileItem4.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem4.setForeground(new Color( 49, 19, 62 ));
	   fileItem4.setMnemonic(KeyEvent.VK_S);//Alt+S
	   
	   filemenu.add(fileItem1);
	   filemenu.add(fileItem2);
	   filemenu.add(fileItem3);
	   filemenu.add(fileItem4);
	   
	   

	   JMenu editmenu = new JMenu("Edit");
	   editmenu.add(new JSeparator());
	   editmenu.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editmenu.setForeground(new Color( 49, 19, 62 ));
	   editmenu.setMnemonic(KeyEvent.VK_E);//Alt+e
	   
	   JMenuItem editItem1 = new JMenuItem("Cut");
	   editItem1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem1.setForeground(new Color( 49, 19, 62 ));
	   editItem1.setMnemonic(KeyEvent.VK_X);//Alt+x
	   
	   
	   JMenuItem editItem2 = new JMenuItem("Copy");
	   editItem2.add(new JSeparator());
	   editItem2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem2.setForeground(new Color( 49, 19, 62 ));
	   editItem2.setMnemonic(KeyEvent.VK_C);//Alt+C
	   
	    
	   JMenuItem editItem3 = new JMenuItem("Paste");
	   editItem3.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem3.setForeground(new Color( 49, 19, 62 ));
	   editItem3.setMnemonic(KeyEvent.VK_V);//Alt+V
	   
	   JMenuItem editItem4 = new JMenuItem("Insert");
	   editItem4.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem4.setForeground(new Color( 49, 19, 62 ));
	   editItem4.setMnemonic(KeyEvent.VK_I);//Alt+I
	   
	   
	   editmenu.add(editItem1);
	   editmenu.add(editItem2);
	   editmenu.add(editItem3);
	   editmenu.add(editItem4);
	   
	   
	   JMenu optionmenu = new JMenu("Option");
	   optionmenu.add(new JSeparator());
	   optionmenu.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenu.setForeground(new Color( 49, 19, 62 ));
	   optionmenu.setMnemonic(KeyEvent.VK_E);//Alt+e
	   
	   
	   JMenuItem optionmenuItem = new JMenuItem("Commands");
	   optionmenuItem.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenuItem.setForeground(new Color( 49, 19, 62 ));
	   optionmenuItem.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   
	   JMenuItem optionmenuItem1 = new JMenuItem("WrittingText");
	   optionmenuItem1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenuItem1.setForeground(new Color( 49, 19, 62 ));
	   optionmenuItem1.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   JMenuItem optionmenuItem2 = new JMenuItem("Modify");
	   optionmenuItem2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenuItem2.setForeground(new Color( 49, 19, 62 ));
	   optionmenuItem2.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   optionmenu.add(optionmenuItem);
	   optionmenu.add(optionmenuItem1);
	   optionmenu.add(optionmenuItem2);
	  
	   menubar.add(filemenu);
	   menubar.add(editmenu);
	   menubar.add(optionmenu);
    return menubar;// Return the Main Menubar
    
} // Ends method menuBar
}