

public interface Dbinitializer {
	
	final public String Driver="com.mysql.jdbc.Driver";
	final public String db = "jdbc:mysql://localhost:3306/atm";
	final public String username ="root";
	final public String password ="admin";

}
