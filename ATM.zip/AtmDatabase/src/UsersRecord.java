

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.sql.*;
import java.awt.event.*;

@SuppressWarnings("unused")
public class UsersRecord {
	JFrame frame1;
	JTextField textbox;
	JLabel label;
	JButton button;
	JPanel panel;
	static JTable table;
	
	String driverName = "com.mysql.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/atm";
	String userName = "root";
	String password = "admin";
	String[] columnNames = {"FullName", "Address", "Contact", "Email","Telephone", "Gender", "AltMob","AccNo","Amount","Depts"};

	public UsersRecord() {
		// TODO Auto-generated constructor stub
		
		frame1 = new JFrame("Database Search Result");
		frame1.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);//To keep the Frame in full size view all time
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.setLayout(new BorderLayout());		
		
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columnNames);
		
		table = new JTable();
		table.setModel(model);	
		
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		
		table.setFillsViewportHeight(true);
		
		JScrollPane scroll = new JScrollPane(table);
		
		scroll.setHorizontalScrollBarPolicy(
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		scroll.setVerticalScrollBarPolicy(
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);		
		
		
		String FullName= "";
		String Address= "";
		String Contact = "";
		String Email = "";
		String Telephone= "";
		String Gender= "";
		String AltMob = "";
		String AccNO="";
		String Amount="";
		String Depts="";
		
		
		try
		{			
			Class.forName(driverName);		
			Connection con = DriverManager.getConnection(url, userName, password);
			String sql = "select us.*,usd.AccNo,usd.amount,usd.depts from user us inner join userdetails usd  on us.Email=usd.Email;";
			PreparedStatement ps = con.prepareStatement(sql);
	        ResultSet rs = ps.executeQuery();
	        int i =0;
			while(rs.next())
	        {
				FullName = rs.getString(1);
				Address = rs.getString(2);
				Contact = rs.getString(3);
				Email = rs.getString(4);					
				Telephone = rs.getString(5);
				Gender = rs.getString(6);
				AltMob = rs.getString(7);
				AccNO = rs.getString(11);
				Amount = rs.getString(12);
				Depts = rs.getString(13);
				
				
				model.addRow(new Object[]{FullName, Address, Contact, Email,Telephone,Gender,AltMob,AccNO,Amount,Depts});
				i++;				
	        }
			if(i <1)
			{
				JOptionPane.showMessageDialog(null, "No Record Found","Error",
						JOptionPane.ERROR_MESSAGE);
			}
			
			if(i ==1)
			{
			System.out.println(i+" Record Found");
			}
			else
			{
				System.out.println(i+" Records Found");
			}
		}
		catch(Exception ex)
		{
			JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",
					JOptionPane.ERROR_MESSAGE);
		}
		
		
		JButton back=new JButton("Back");
		back.setBounds(1100, 800, 100, 40);
		back.setFont(new Font("Rockwell", Font.BOLD, 18));
		back.setForeground(new Color( 49, 19, 62 ));
		
		
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			new UserSide();	
			frame1.dispose();
			}
		});
		frame1.add(back);
		
		frame1.add(scroll);
		frame1.setVisible(true);
		//frame1.setSize(600,600);
	}
	
	public static void main(String[] args) {
	new	UsersRecord();
	}
	
}
