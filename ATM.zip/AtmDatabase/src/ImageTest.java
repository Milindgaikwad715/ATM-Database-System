  
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class ImageTest {

	public ImageTest()
	{
	new FrameDesign();
	}
	
	public static void main(String[] args) {
		new ImageTest();
	}
}




class FrameDesign
{
	
public FrameDesign() {
	
	ImagePanel p = new ImagePanel(new ImageIcon("1.jpg").getImage());
	
	JFrame frame = new JFrame("Registration Form");
	   frame.setSize(700, 800);
	
	   
	   JLabel Heading=new JLabel("Registration Form");
	   Heading.setFont(new Font("Rockwell", Font.BOLD, 30));
	   Heading.setForeground(new Color(243, 156, 18));
	   Heading.setBounds(500, 10, 500, 40);
	   p.add(Heading);
	   
	   JLabel design=new JLabel(">>>>>>>>>>*<<<<<<<<<<");
	   design.setFont(new Font("Rockwell", Font.BOLD, 20));
	   design.setForeground(new Color( 25, 233, 224 ));
	   design.setBounds(500, 40, 500, 40);
	   p.add(design);
	   
	   
	   
	  /* JMenuBar menubar = new JMenuBar();
	   menubar.setBackground(Color.yellow);
	   menubar.setSize(699, 699);
	   
	  
	   JMenu filemenu = new JMenu("File");
	   filemenu.add(new JSeparator());
	   filemenu.setFont(new Font("Rockwell", Font.BOLD, 18));
	   filemenu.setForeground(new Color( 49, 19, 62 ));
	   filemenu.setMnemonic(KeyEvent.VK_F);//Alt+f
	   
	   
	   JMenuItem fileItem1 = new JMenuItem("New");
	   fileItem1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem1.setForeground(new Color( 49, 19, 62 ));
	
	   fileItem1.setAccelerator(KeyStroke.getKeyStroke('N', Toolkit.getDefaultToolkit ().getMenuShortcutKeyMask()));

	   JMenuItem fileItem2 = new JMenuItem("Open");
	   fileItem2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem2.setForeground(new Color( 49, 19, 62 ));
	   fileItem2.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   JMenuItem fileItem3 = new JMenuItem("Close");
	   fileItem3.add(new JSeparator());
	   fileItem3.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem3.setForeground(new Color( 49, 19, 62 ));
	   
	   JMenuItem fileItem4 = new JMenuItem("Save");
	   fileItem4.setFont(new Font("Rockwell", Font.BOLD, 18));
	   fileItem4.setForeground(new Color( 49, 19, 62 ));
	   fileItem4.setMnemonic(KeyEvent.VK_S);//Alt+S
	   
	   filemenu.add(fileItem1);
	   filemenu.add(fileItem2);
	   filemenu.add(fileItem3);
	   filemenu.add(fileItem4);
	   
	   

	   JMenu editmenu = new JMenu("Edit");
	   editmenu.add(new JSeparator());
	   editmenu.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editmenu.setForeground(new Color( 49, 19, 62 ));
	   editmenu.setMnemonic(KeyEvent.VK_E);//Alt+e
	   
	   JMenuItem editItem1 = new JMenuItem("Cut");
	   editItem1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem1.setForeground(new Color( 49, 19, 62 ));
	   editItem1.setMnemonic(KeyEvent.VK_X);//Alt+x
	   
	   
	   JMenuItem editItem2 = new JMenuItem("Copy");
	   editItem2.add(new JSeparator());
	   editItem2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem2.setForeground(new Color( 49, 19, 62 ));
	   editItem2.setMnemonic(KeyEvent.VK_C);//Alt+C
	   
	    
	   JMenuItem editItem3 = new JMenuItem("Paste");
	   editItem3.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem3.setForeground(new Color( 49, 19, 62 ));
	   editItem3.setMnemonic(KeyEvent.VK_V);//Alt+V
	   
	   JMenuItem editItem4 = new JMenuItem("Insert");
	   editItem4.setFont(new Font("Rockwell", Font.BOLD, 18));
	   editItem4.setForeground(new Color( 49, 19, 62 ));
	   editItem4.setMnemonic(KeyEvent.VK_I);//Alt+I
	   
	   
	   editmenu.add(editItem1);
	   editmenu.add(editItem2);
	   editmenu.add(editItem3);
	   editmenu.add(editItem4);
	   
	   
	   JMenu optionmenu = new JMenu("Option");
	   optionmenu.add(new JSeparator());
	   optionmenu.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenu.setForeground(new Color( 49, 19, 62 ));
	   optionmenu.setMnemonic(KeyEvent.VK_E);//Alt+e
	   
	   
	   JMenuItem optionmenuItem = new JMenuItem("Commands");
	   optionmenuItem.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenuItem.setForeground(new Color( 49, 19, 62 ));
	   optionmenuItem.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   
	   JMenuItem optionmenuItem1 = new JMenuItem("WrittingText");
	   optionmenuItem1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenuItem1.setForeground(new Color( 49, 19, 62 ));
	   optionmenuItem1.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   JMenuItem optionmenuItem2 = new JMenuItem("Modify");
	   optionmenuItem2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   optionmenuItem2.setForeground(new Color( 49, 19, 62 ));
	   optionmenuItem2.setMnemonic(KeyEvent.VK_O);//Alt+E
	   
	   optionmenu.add(optionmenuItem);
	   optionmenu.add(optionmenuItem1);
	   optionmenu.add(optionmenuItem2);
	  
	   menubar.add(filemenu);
	   menubar.add(editmenu);
	   menubar.add(optionmenu);
	   frame.setJMenuBar(menubar);*/
	   
	   frame.setJMenuBar(menubar.menuBar());// just call the Menubar Class & its constructor
	   
	   JLabel Fname=new JLabel("FullName:");
	   Fname.setBounds(500, 100, 100, 30);
	   Fname.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Fname.setForeground(new Color( 49, 19, 62 ));
	   p.add(Fname);
	   
	   JTextField TxName=new JTextField(25);
	   TxName.setBounds(610, 100, 150, 30);
	   TxName.setFont(new Font("Rockwell", Font.BOLD, 18));
	   TxName.setForeground(new Color( 49, 19, 62 ));
	   p.add(TxName);
	   
	   
	   JLabel LAdd=new JLabel("Address   :");
	   LAdd.setBounds(500, 140, 100, 30);
	   LAdd.setFont(new Font("Rockwell", Font.BOLD, 18));
	   LAdd.setForeground(new Color( 49, 19, 62 ));
	   p.add(LAdd);
	  
	 
	   JTextArea Add=new JTextArea(5,20);
	   Add.setBounds(610, 140, 150, 30);
	   
	   Add.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Add.setForeground(new Color( 49, 19, 62 ));
	   
	   Add.setLineWrap(true);
	   JScrollPane Pane = new JScrollPane(Add, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	      frame.add(Add);
	   
	   

	   
	   JLabel Contact=new JLabel("Contact   :");
	   Contact.setBounds(500, 180, 100, 30);
	   Contact.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Contact.setForeground(new Color( 49, 19, 62 ));
	   p.add(Contact);
	   
	   JTextField TXCon=new JTextField(25);
	   TXCon.setBounds(610, 180, 150, 30);
	   TXCon.setFont(new Font("Rockwell", Font.BOLD, 18));
	   TXCon.setForeground(new Color( 49, 19, 62 ));
	   p.add(TXCon);
	   
	   JLabel Email=new JLabel("Email      :");
	   Email.setBounds(500, 220, 100, 30);
	   Email.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Email.setForeground(new Color( 49, 19, 62 ));
	   p.add(Email);
	   
	   JTextField TxEmail=new JTextField(25);
	   TxEmail.setBounds(610, 220, 150, 30);
	   TxEmail.setFont(new Font("Rockwell", Font.BOLD, 18));
	   TxEmail.setForeground(new Color( 49, 19, 62 ));
	   p.add(TxEmail);
	   
	   JLabel Telephone=new JLabel("Telephone:");
	   Telephone.setBounds(500, 260, 100, 30);
	   Telephone.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Telephone.setForeground(new Color( 49, 19, 62 ));
	   p.add(Telephone);
	   
	   JTextField TXTele=new JTextField(25);
	   TXTele.setBounds(610, 260, 150, 30);
	   TXTele.setFont(new Font("Rockwell", Font.BOLD, 18));
	   TXTele.setForeground(new Color( 49, 19, 62 ));
	   p.add(TXTele);
	   
	   JLabel Gender=new JLabel("Gender    :");
	   Gender.setBounds(500, 300, 100, 30);
	   Gender.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Gender.setForeground(new Color( 49, 19, 62 ));
	   p.add(Gender);
	   
	   ButtonGroup buttonGroup = new ButtonGroup();
	   
	   JRadioButton M=new JRadioButton("Male");
	   M.setBounds(610, 300, 80, 30);
	   M.setFont(new Font("Rockwell", Font.BOLD, 18));
	   M.setForeground(new Color( 49, 19, 62 ));
	   p.add(M);
	   //M.setSelected(true);
	   buttonGroup.add(M);
	   
	   JRadioButton F=new JRadioButton("Female");
	   F.setBounds(700, 300, 100, 30);
	   F.setFont(new Font("Rockwell", Font.BOLD, 18));
	   F.setForeground(new Color( 49, 19, 62 ));
	   p.add(F);
	   buttonGroup.add(F);
	   
	   JLabel ConT2=new JLabel("Alt.MOB  :");
	   ConT2.setBounds(500, 340, 100, 30);
	   ConT2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   ConT2.setForeground(new Color( 49, 19, 62 ));
	   p.add(ConT2);
	   
	   JTextField tecon2=new JTextField(25);
	   tecon2.setBounds(610, 340, 150, 30);
	   tecon2.setFont(new Font("Rockwell", Font.BOLD, 18));
	   tecon2.setForeground(new Color( 49, 19, 62 ));
	   p.add(tecon2);
	   
	   JLabel username=new JLabel("Username:");
	   username.setBounds(500, 380, 100, 30);
	   username.setFont(new Font("Rockwell", Font.BOLD, 18));
	   username.setForeground(new Color( 49, 19, 62 ));
	   p.add(username);
	   
	   JTextField TxUser=new JTextField(25);
	   TxUser.setBounds(610, 380, 150, 30);
	   TxUser.setFont(new Font("Rockwell", Font.BOLD, 18));
	   TxUser.setForeground(new Color( 49, 19, 62 ));
	   p.add(TxUser);
	   
	   JLabel Pass=new JLabel("Password :");
	   Pass.setBounds(500, 420, 100, 30);
	   Pass.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Pass.setForeground(new Color( 49, 19, 62 ));
	   p.add(Pass);
	   
	   JPasswordField Txpass=new JPasswordField(20);
	   Txpass.setBounds(610, 420, 150, 30);
	   Txpass.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Txpass.setForeground(new Color( 49, 19, 62 ));
	   p.add(Txpass);
	   
	   JLabel ConfirmPass=new JLabel("Con.Pass:");
	   ConfirmPass.setBounds(500, 460, 100, 30);
	   ConfirmPass.setFont(new Font("Rockwell", Font.BOLD, 18));
	   ConfirmPass.setForeground(new Color( 49, 19, 62 ));
	   p.add(ConfirmPass);
	   
	   JPasswordField Txconpass=new JPasswordField();
	   Txconpass.setBounds(610, 460, 150, 30);
	   Txconpass.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Txconpass.setForeground(new Color( 49, 19, 62 ));
	   p.add(Txconpass);
	   
	   
	   JButton Submit=new JButton("Submit");
	   Submit.setBounds(550, 550, 100, 30);
	   Submit.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Submit.setForeground(new Color( 49, 19, 62 ));
	   p.add(Submit);
	   
	   
	   JButton Cancel=new JButton("Cancel");
	   Cancel.setBounds(670, 550, 100, 30);
	   Cancel.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Cancel.setForeground(new Color( 49, 19, 62 ));
	   p.add(Cancel);
	   
	   p.setBounds(100, 20, 300, 520);
	   p.setLayout(null);
	   p.setBorder(BorderFactory.createDashedBorder(Color.RED));
	   
	    frame.getContentPane().add(p);
	    frame.pack();
	    frame.setVisible(true);
	
}	
}




