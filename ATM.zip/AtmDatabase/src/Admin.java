import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;




public class Admin {

	
	JLabel Fname;
	JTextField TxName;
	 JLabel LAdd;
	 JTextArea Add;
	 JLabel Contact;
	 JTextField TXCon;
	 JLabel Email;
	 JTextField TxEmail;
	 JLabel Telephone;
	 JTextField TXTele;
	 JLabel Gender;
	 JRadioButton M;
	 JRadioButton F;
	 JLabel ConT2;
	 JTextField tecon2;
	 JLabel username;
	 JTextField TxUser;
	 JLabel Pass;
	 JPasswordField Txpass;
	 JPasswordField PassTx;
	 JLabel ConfirmPass;
	 JPasswordField Txconpass;
	 JTextField Txlogin;

	String Gen=null;
	
	public Admin() {
		// TODO Auto-generated constructor stub
		
		final JFrame f=new JFrame("Admin Section");
		//f.setSize(800, 800);
		f.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);//To keep the Frame in full size view all time
		
		
		ImagePanel p=new ImagePanel("ATMDB.jpg"); //Main Panel on which i m Writing the code
		
		JLabel Heading=new JLabel("Welcome  Admin");
		Heading.setBounds(370, 20, 400, 30);
		Heading.setFont(new Font("Rockwell", Font.BOLD, 30));
		Heading.setForeground(new Color( 254, 245, 231 ));
		   f.add(Heading);
		   
		   
		   // Start the Registration Form on Register ImagePanel
		   
		   ImagePanel p1=new ImagePanel("Registration.jpg");//RegisterPanel
		   p1.setBounds(15, 100, 500, 700);
		
		   JLabel Heading1=new JLabel("RegistrationForm");
			Heading1.setBounds(80, 5, 400, 35);
			Heading1.setFont(new Font("Rockwell", Font.BOLD, 30));
			Heading1.setForeground(new Color( 254, 245, 231 ));
			   p1.add(Heading1);
			
		   
		    Fname=new JLabel("FullName:");
		   Fname.setBounds(30, 80, 100, 30);
		   Fname.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Fname.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Fname);
		   
		   TxName=new JTextField(25);
		   TxName.setBounds(140, 80, 200, 30);
		   TxName.setFont(new Font("Rockwell", Font.BOLD, 18));
		   TxName.setForeground(new Color( 49, 19, 62 ));
		   p1.add(TxName);
		   
		   
		  LAdd=new JLabel("Address   :");
		   LAdd.setBounds(30, 120, 100, 30);
		   LAdd.setFont(new Font("Rockwell", Font.BOLD, 18));
		   LAdd.setForeground(new Color( 49, 19, 62 ));
		   p1.add(LAdd);
		  
		 
		    Add=new JTextArea(5,20);
		   Add.setBounds(140, 120, 200, 30);
		   
		   Add.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Add.setForeground(new Color( 49, 19, 62 ));
		   
		   Add.setLineWrap(true);
		   JScrollPane Pane = new JScrollPane(Add, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
		   JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		      p1.add(Add);
		   
		   

		       
		   Contact=new JLabel("Contact   :");
		   Contact.setBounds(30, 160, 100, 30);
		   Contact.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Contact.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Contact);
		   
		   TXCon=new JTextField(25);
		   TXCon.setBounds(140, 160, 200, 30);
		   TXCon.setFont(new Font("Rockwell", Font.BOLD, 18));
		   TXCon.setForeground(new Color( 49, 19, 62 ));
		   p1.add(TXCon);
		   
		   
		 Email=new JLabel("Email      :");
		   Email.setBounds(30, 200, 100, 30);
		   Email.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Email.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Email);
		   
		    TxEmail=new JTextField(25);
		   TxEmail.setBounds(140, 200, 200, 30);
		   TxEmail.setFont(new Font("Rockwell", Font.BOLD, 18));
		   TxEmail.setForeground(new Color( 49, 19, 62 ));
		   p1.add(TxEmail);
		   
		    Telephone=new JLabel("Telephone:");
		   Telephone.setBounds(30, 240, 100, 30);
		   Telephone.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Telephone.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Telephone);
		   
		   TXTele=new JTextField(25);
		   TXTele.setBounds(140, 240, 200, 30);
		   TXTele.setFont(new Font("Rockwell", Font.BOLD, 18));
		   TXTele.setForeground(new Color( 49, 19, 62 ));
		   p1.add(TXTele);
		   
		    Gender=new JLabel("Gender    :");
		   Gender.setBounds(30, 275, 100, 30);
		   Gender.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Gender.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Gender);
		   
		   ButtonGroup buttonGroup = new ButtonGroup();
		   
		  M=new JRadioButton("Male");
		   M.setBounds(145, 275, 80, 30);
		   M.setFont(new Font("Rockwell", Font.BOLD, 18));
		   M.setForeground(new Color( 49, 19, 62 ));
		   buttonGroup.add(M);
		   p1.add(M);
		   //M.setSelected(true);
		   
		   M.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
				Gen="Male";
			}
		});
		   
		   
		   
		   
		    F=new JRadioButton("Female");
		   F.setBounds(235, 275, 100, 30);
		   F.setFont(new Font("Rockwell", Font.BOLD, 18));
		   F.setForeground(new Color( 49, 19, 62 ));
		   buttonGroup.add(F);
		   p1.add(F);
		   
		   F.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
				
					Gen="Female";
				}
			});
		   
		   
		  ConT2=new JLabel("Alt.MOB  :");
		   ConT2.setBounds(30, 315, 100, 30);
		   ConT2.setFont(new Font("Rockwell", Font.BOLD, 18));
		   ConT2.setForeground(new Color( 49, 19, 62 ));
		   p1.add(ConT2);
		   
		  tecon2=new JTextField(25);
		   tecon2.setBounds(140, 315, 200, 30);
		   tecon2.setFont(new Font("Rockwell", Font.BOLD, 18));
		   tecon2.setForeground(new Color( 49, 19, 62 ));
		   p1.add(tecon2);
		   
		  username=new JLabel("Username:");
		   username.setBounds(30, 355, 100, 30);
		   username.setFont(new Font("Rockwell", Font.BOLD, 18));
		   username.setForeground(new Color( 49, 19, 62 ));
		   p1.add(username);
		   
		  TxUser=new JTextField(25);
		   TxUser.setBounds(140, 355, 200, 30);
		   TxUser.setFont(new Font("Rockwell", Font.BOLD, 18));
		   TxUser.setForeground(new Color( 49, 19, 62 ));
		   p1.add(TxUser);
		   
		  Pass=new JLabel("Password :");
		   Pass.setBounds(30, 395, 100, 30);
		   Pass.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Pass.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Pass);
		   
	 Txpass=new JPasswordField(20);
		   Txpass.setBounds(140, 395, 200, 30);
		   Txpass.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Txpass.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Txpass);
		   
	 ConfirmPass=new JLabel("Con.Pass:");
		   ConfirmPass.setBounds(30, 435, 100, 30);
		   ConfirmPass.setFont(new Font("Rockwell", Font.BOLD, 18));
		   ConfirmPass.setForeground(new Color( 49, 19, 62 ));
		   p1.add(ConfirmPass);
		   
		   Txconpass=new JPasswordField();
		   Txconpass.setBounds(140,435, 200, 30);
		   Txconpass.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Txconpass.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Txconpass);
		   
		   
		   JButton Submit=new JButton("Submit");
		   Submit.setBounds(130, 500, 100, 30);
		   Submit.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Submit.setForeground(new Color( 49, 19, 62 ));
		   p1.add(Submit);
		   
		   
		   JButton Cancel=new JButton("Cancel");
		   Cancel.setBounds(240, 500, 100, 30);
		   Cancel.setFont(new Font("Rockwell", Font.BOLD, 18));
		   Cancel.setForeground(new Color( 49, 19, 62 ));
		   
		   //Go to the Admin Page ON cancel Button Click
		   Cancel.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
				new HomePage();
					f.dispose();//close the current frame when switched to previous frame
				}
			});
		   p1.add(Cancel);
		
        //End Registration Form on ImagePanel		
		   
		  
		   //insert the record in Db on Submit Click
		   Submit.addActionListener(new ActionListener() {
			
			@SuppressWarnings("deprecation")
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			
		  int count=0;
		   try{
			   
			   PreparedStatement ps= Dbconnect.con().prepareStatement("insert into admindetails values(?,?,?,?,?,?,?,?,?,?)");
			   ps.setString(1, TxName.getText());
			   ps.setString(2, Add.getText());
			   ps.setString(3, TXCon.getText());
			   ps.setString(4, TxEmail.getText());
			   ps.setString(5, TXTele.getText());
			   ps.setString(6, Gen);
			   ps.setString(7, tecon2.getText());
			   ps.setString(8, TxUser.getText());
			   ps.setString(9, Txpass.getText());
			   ps.setString(10, Txconpass.getText());
			   count=ps.executeUpdate();
				
			   if(count>0)
			   {
				   System.out.println(count +": rows are Affected...");
				   
				   JOptionPane.showMessageDialog(null, "Record Inserted Successfully");
			   }
		   }
		   catch( Exception e1)
		   {
			   JOptionPane.showMessageDialog(null, e1.getMessage());
			   
			   e1.printStackTrace();
		   }
		   

			}
			});
		   
		   
		   
		   // Start The Login Form on ImagePanel
		   
		   
		   
		   
		   
		
		ImagePanel p2=new ImagePanel("Login11.jpg");//LoginPanel call login form
		p2.setBounds(550, 100, 500, 700);
		
		
		JLabel Heading2=new JLabel("Login Form");
		Heading2.setBounds(100, 5, 400, 35);
		Heading2.setFont(new Font("Rockwell", Font.BOLD, 30));
		Heading2.setForeground(new Color( 254, 245, 231 ));
		   p2.add(Heading2);
		
	   
	   JLabel login=new JLabel("Username :");
	   login.setBounds(30, 80, 100, 30);
	   login.setFont(new Font("Rockwell", Font.BOLD, 18));
	   login.setForeground(new Color( 49, 19, 62 ));
	   p2.add(login);
	   
	    Txlogin=new JTextField(25);
	   Txlogin.setBounds(140, 80, 200, 30);
	   Txlogin.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Txlogin.setForeground(new Color( 49, 19, 62 ));
	   p2.add(Txlogin);
	   
	   JLabel Pass1=new JLabel("Password :");
	   Pass1.setBounds(30, 120, 100, 30);
	   Pass1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Pass1.setForeground(new Color( 49, 19, 62 ));
	   p2.add(Pass1);
	   
	   
	   PassTx=new JPasswordField();
	   PassTx.setBounds(140, 120, 200, 30);
	   PassTx.setFont(new Font("Rockwell", Font.BOLD, 18));
	   PassTx.setForeground(new Color( 49, 19, 62 ));
	   p2.add(PassTx);
		
	   ImageIcon ic=new ImageIcon("login-button-blue.jpg");
	   
	   JButton BtnLogin=new JButton(ic);
	   BtnLogin.setBounds(120, 200, 130, 50);
	   BtnLogin.setFont(new Font("Rockwell", Font.BOLD, 18));
	   BtnLogin.setForeground(new Color( 49, 19, 62 ));
	   p2.add(BtnLogin);
	   
	   
	   
	   BtnLogin.addActionListener(new ActionListener() {
		
		@SuppressWarnings("deprecation")
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			String unm=null;
			String pass=null;
			try{
				
				String sql="select * from sptotx.admindetails";
				PreparedStatement pst=Dbconnect.con().prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					unm=rs.getString(8);
				
					pass=rs.getString(9);
				}
				
				if(Txlogin.getText().equals(unm) && PassTx.getText().equals(pass))
				{
					System.out.println("welcome:  " +unm );
					new UsersRecord();
					f.dispose();
					
				}
				else
				{
					
					JOptionPane.showMessageDialog(null, "Please Enter Valid Username/Pass Or Register");
				}
				
			}
			catch(Exception e2)
			{
				JOptionPane.showMessageDialog(null, e2.getMessage());
				e2.printStackTrace();
				
			}
	
		}
	});
	   
	   ImageIcon ic1=new ImageIcon("cancel-button-hi.png");
	   
	   JButton Cancel1=new JButton(ic1);
	   Cancel1.setBounds(270, 200, 130, 50);
	   Cancel1.setFont(new Font("Rockwell", Font.BOLD, 18));
	   Cancel1.setForeground(new Color( 49, 19, 62 ));
	  
	   Cancel1.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
		new HomePage();
		f.dispose();         //close the current frame when switched to previous frame
		}
	});
	   p2.add(Cancel1);
	   
	// End The Login Form on ImagePanel
	   
		
		p.add(p1);//Register panel added in main panel
		p.add(p2);//login panel added in main panel
		
		
		//f.setJMenuBar(menubar.menuBar());// just call the Menubar Class & its constructor
		
		
		// Button for Seperation between two Imagepanels
				JButton Seprator=new JButton();
				Seprator.setBounds(520, 100, 20, 700);
				Seprator.setBackground(new Color(243, 156, 18));
				Seprator.setOpaque(true);
				
				f.add(Seprator);
		f.add(p);//main Panel Added In frame
		f.setDefaultCloseOperation(f.EXIT_ON_CLOSE);
		f.setVisible(true);
		
	}
	public static void main(String[] args) {
		new Admin();
	}
	

}
